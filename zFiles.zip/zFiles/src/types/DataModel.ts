export interface DataModel {
    id: number,
    label:string,
    description : string,
    otherEndId : number
    type : "input" | "logic" | "output"
}

export const sampleData: DataModel[] = [
    // Inputs (Sensors) - All Inputs must connect to at least one Logic Block
    { id: 1, label: "PressureSensor_1", description: "Pressure sensor reading from tank A", otherEndId: 102, type: "input" },
    { id: 2, label: "TemperatureSensor_2", description: "Temperature sensor reading from reactor B", otherEndId: 102, type: "input" },
    { id: 3, label: "FlowSensor_3", description: "Flow rate measurement for coolant line C", otherEndId: 103, type: "input" },
    { id: 4, label: "LevelSensor_4", description: "Level sensor reading from mixing tank D", otherEndId: 104, type: "input" },
    { id: 5, label: "MotorSpeedSensor_5", description: "Motor Speed sensor for conveyor belt E", otherEndId: 105, type: "input" },

    // Logic Blocks - Ensuring each has at least one Input or Logic connection
    { id: 101, label: "PressureLogic_A", description: "Logic for pressure threshold in tank A", otherEndId: 106, type: "logic" }, // Links to CombinedLogic_AB
    { id: 102, label: "TemperatureLogic_B", description: "Logic for temperature control in reactor B", otherEndId: 106, type: "logic" }, // Links to CombinedLogic_AB
    { id: 103, label: "FlowLogic_C", description: "Logic for flow rate regulation in coolant line C", otherEndId: 107, type: "logic" }, // Links to InterlockLogic_CD
    { id: 104, label: "LevelLogic_D", description: "Logic for mixing tank D level control", otherEndId: 107, type: "logic" }, // Links to InterlockLogic_CD
    { id: 105, label: "MotorSpeedLogic_E", description: "Logic for conveyor belt E motor speed control", otherEndId: 108, type: "logic" }, // Links to FinalControlLogic

    // Intermediate Logic Blocks (Ensuring each has an Input or Logic connection)
    { id: 106, label: "CombinedLogic_AB", description: "Combines Pressure A & Temperature B logic", otherEndId: 202, type: "logic" }, // Ends at Output
    { id: 107, label: "InterlockLogic_CD", description: "Interlock Logic based on Flow C and Level D", otherEndId: 204, type: "logic" }, // Ends at Output
    { id: 108, label: "FinalControlLogic", description: "Final control logic based on multiple inputs", otherEndId: 207, type: "logic" }, // Ends at Output

    // Outputs - Set `otherEndId: 0`, ensuring they are terminal nodes
   
    { id: 202, label: "Heater_B_Activate", description: "Activate heater in reactor B when temperature is low", otherEndId: 0, type: "output" },
    { id: 204, label: "Mixer_D_Start", description: "Start mixer in tank D when level is within range", otherEndId: 0, type: "output" },
    { id: 207, label: "Final_Output_Control", description: "Final output based on interlock logic", otherEndId: 0, type: "output" }
];

