import { useEffect, useRef, useState } from "react";
import { DefaultLabelStyle, FreeNodeLabelModel, FreeNodePortLocationModel, GraphComponent, GraphEditorInputMode, GroupNodeLabelModel, GroupNodeStyle, HierarchicLayout, HierarchicLayoutData, ICanvasObjectDescriptor, IGraph, INode, LayoutExecutor, LayoutOrientation, Mapper, NodeStyleStripeStyleAdapter, OrganicLayout, PartitionCellId, PartitionGrid, PartitionGridData, Point, Rect, ShapeNodeStyle, Size, StringTemplateNodeStyle, Table, TableNodeStyle, TimeSpan, TreeLayout } from "yfiles";
import { DataModel, sampleData } from "./types/DataModel";
import SimplePartitionGridVisualCreator from "./archive/SimplePartitionGridVisualCreator";
import { rect } from "highcharts";
import React from "react";
import { template } from "./tempate/roottemplate";
import { parentNodes } from "./data";
import ContainerVisulization from "./archive/ContainerVisulization";

export default function FLGLogic4() {
    const graphDivRef = useRef<HTMLDivElement>(null);
    const graphComponent = useRef<GraphComponent | null>(null);
    const [graph, setGraph] = useState<IGraph | null>(null);

    useEffect(() => {
        if (graphDivRef.current && !graphComponent.current) {
            graphComponent.current = new GraphComponent(graphDivRef.current);
            setGraph(graphComponent.current.graph);
        }
    }, [graphDivRef.current]);

    useEffect(() => {
        if (graph) {
            console.debug("Graph Updated");
            graphComponent.current!.fitGraphBounds();
            graphComponent.current!.inputMode = new GraphEditorInputMode();

            //addRootNodes();
            createLayoutData();

        }
    }, [graph]);

    async function createLayoutData() {
        if (graph && graphComponent.current) {
            const partitionGridData = createFldTable(sampleData);
            const layout = new HierarchicLayout({
                layoutOrientation: LayoutOrientation.LEFT_TO_RIGHT,
                nodeToNodeDistance: 150,
                considerNodeLabels: true
            });
            if (partitionGridData) {
                const layoutData = new HierarchicLayoutData({
                    partitionGridData: partitionGridData
                });

                // Create a layout executor to animate the layout
                const executor = new LayoutExecutor({
                    graphComponent: graphComponent.current,
                    layout: layout,
                    layoutData: layoutData,
                    duration: TimeSpan.fromSeconds(1.5),
                    animateViewport: true,
                    easedAnimation: true
                });

                // Execute the layout with animation
                await executor.start();

                // Final adjustment to ensure everything is visible
                graphComponent.current.fitGraphBounds();
            }


            graphComponent.current!.fitGraphBounds();
        }
    }

    async function createFldTable(data: DataModel[]) {
        if (graph && graphComponent.current) {
            const nodeMap = new Map<number, any>();

            const templateNodeStyle = new StringTemplateNodeStyle(template);
                
            // Create the parent nodes with proper spacing based on template dimensions
            const node1 = graph.createNode(new Rect(0, 0, 269.37, 130));
            node1.tag = parentNodes[0];
            graph.setStyle(node1, templateNodeStyle);
            
            const node2 = graph.createNode(new Rect(600, 0, 269.37, 130));
            node2.tag = parentNodes[1];
            graph.setStyle(node2, templateNodeStyle);
            
            // Create an edge between the two parent nodes
            const portAtNode1 = graph.addPort(node1, FreeNodePortLocationModel.NODE_RIGHT_ANCHORED);
            const portAtNode2 = graph.addPort(node2, FreeNodePortLocationModel.NODE_LEFT_ANCHORED);
           
    
            // Define colors for different node types
            const colorMap: Record<string, string> = {
                input: "green",
                logic: "blue",
                output: "red",
            };

            let fldGroup = graph.createGroupNode({
                layout: new Rect(0, 0, 1000, 500), // Define the size of the group
                style: new GroupNodeStyle({
                    tabFill: null,  // Transparent tab
                    tabBackgroundFill: null, // Transparent tab background
                    stroke: "none",  // No border
                    contentAreaFill: null,
                    contentAreaInsets : [20,15,15,15],
                    tabPosition:"top",
                    tabInset : 10,
                    tabHeight : 24,
                    tabWidth : 20,
                })
            });

            graph.createEdge(node1, fldGroup);
            graph.createEdge(fldGroup, node2);

            graph.addLabel({
                owner: fldGroup,
                text: "Group Node",
                layoutParameter: new GroupNodeLabelModel().createDefaultParameter()
            });
    
               var partiationGrid = new PartitionGrid(1,3);
               const partitionGridVisualizer = new SimplePartitionGridVisualCreator(partiationGrid);
              
                graphComponent.current.backgroundGroup.addChild(partitionGridVisualizer,ICanvasObjectDescriptor.ALWAYS_DIRTY_INSTANCE);
               
                 partiationGrid.columns.forEach((column) => {
                if(column.index == 0)
                {
                  column.minimumWidth = 200;
                  column.computedWidth = 200;
                  column.computedPosition = 0;
                  column.leftInset = 10;
                }
                else if(column.index == 1)
                {
                  column.minimumWidth = 500;
                  column.computedWidth = 500;
                  column.computedPosition = 200;
                  column.leftInset = 30;
                }
                else if(column.index == 2)
                {
                  column.minimumWidth = 200;
                  column.computedWidth = 200;
                  column.computedPosition = 700;
                  column.leftInset = 10;
                }
              });
            var cellMapper = new Mapper<INode,PartitionCellId>();
            // Step 1: Create nodes and store references in a map
            let nodes:INode[] = [];
            data.forEach((element) => {
                let node = graph.createNode({
                    tag: element,
                    parent:fldGroup,
                   layout : new Rect(0,0,150,80)
                });
                graph.addLabel(node, element.label);
                nodeMap.set(element.id, node);
                nodes.push(node);

                if(element.type == "input")
                    cellMapper.set(node, partiationGrid.createCellId(0, 0));
               else if(element.type == "logic")
                   cellMapper.set(node, partiationGrid.createCellId(0, 1));
               else
                   cellMapper.set(node, partiationGrid.createCellId(0, 2));
            });
    
           
            // Step 2: Create edges based on otherEndId
            data.forEach((element) => {
                if (element.otherEndId) {
                    const sourceNode = nodeMap.get(element.id);
                    const targetNode = nodeMap.get(element.otherEndId);
    
                    if (sourceNode && targetNode) {
                        graph.createEdge(sourceNode, targetNode);
                    }
                }
            });

            

            const partitionGridData = new PartitionGridData({
                grid: partiationGrid,
                cellIds: cellMapper
              });

              const layout = new HierarchicLayout({
                layoutOrientation: LayoutOrientation.LEFT_TO_RIGHT,
                nodeToNodeDistance: 150,
                considerNodeLabels: true
            });

            const layoutData = new HierarchicLayoutData({
                partitionGridData: partitionGridData
              });
            

            

            // Create a layout executor to animate the layout
            const executor = new LayoutExecutor({
                graphComponent: graphComponent.current,
                layout: layout,
                layoutData: layoutData,
                duration: TimeSpan.fromSeconds(1.5),
                animateViewport: true,
                easedAnimation: true
            });
            
            // Execute the layout with animation
            await executor.start();

            // Final adjustment to ensure everything is visible
            graphComponent.current.fitGraphBounds();
        }
    }


    function addRootNodes() {
            if (graph) {
                console.debug("Adding Root Nodes");
                
                // Create the template style for parent nodes
                const templateNodeStyle = new StringTemplateNodeStyle(template);
                
                // Create the parent nodes with proper spacing based on template dimensions
                const node1 = graph.createNode(new Rect(0, 0, 269.37, 130));
                node1.tag = parentNodes[0];
                graph.setStyle(node1, templateNodeStyle);
                
                const node2 = graph.createNode(new Rect(600, 0, 269.37, 130));
                node2.tag = parentNodes[1];
                graph.setStyle(node2, templateNodeStyle);
                
                // Create an edge between the two parent nodes
                const portAtNode1 = graph.addPort(node1, FreeNodePortLocationModel.NODE_RIGHT_ANCHORED);
                const portAtNode2 = graph.addPort(node2, FreeNodePortLocationModel.NODE_LEFT_ANCHORED);
                graph.createEdge(portAtNode1, portAtNode2);
    
                // Apply initial layout
                const hierarchicLayout = new HierarchicLayout();
                hierarchicLayout.nodeToNodeDistance = 400; // Increased to accommodate larger nodes
                hierarchicLayout.layoutOrientation = LayoutOrientation.LEFT_TO_RIGHT;
                
                graph.applyLayout(hierarchicLayout);
                graphComponent.current!.fitGraphBounds();
            }
        }

    return (<>
        <div 
        ref={graphDivRef}
        style={{ width: '1000px', height: '600px', border: '1px solid #ccc' }}
      />
    </>)
}