export const template = `<g  class="yfiles-highlighted">
        <rect stroke="#D5684D" fill="#FFFFFF" class="hoverable" fill-opacity="1" stroke-width="2" height="130" width="269.37"></rect>
        <rect fill="#D77357" class="hoverable" fill-opacity="1" stroke-width="2" height="25" width="269.37" data-attr1="true"></rect>
        <text font-family="Arial" font-size="12px" font-style="normal" font-weight="normal" text-anchor="middle" fill="white" fill-opacity="1" dy="1em" x="134.685" y="4.5" data-content="{Binding LogicalBlockName}"></text>
        <use x="250.37" y="0" transform="rotate(0)" visibility="hidden" href="#ygc1_1">
        </use>
        <rect fill="#FFEEE4" class="hoverable" fill-opacity="1" stroke-width="2" height="25" x="1" y="25" width="267.37"></rect>
        <text font-family="Arial" font-size="11px" font-style="normal" font-weight="normal" text-anchor="left" fill="while" fill-opacity="1" dy="1em" width="269.37" x="15" y="30"> Desc: Controller Example 1
            <title>Controller Example 1</title>
        </text>
        
        <text font-family="Arial" font-size="10px" font-style="normal" font-weight="normal" text-anchor="left" fill="while" fill-opacity="1" x="15" y="55">
            <tspan x="15" dy="1.1em">
                Type: <tspan style="font-family: Arial; font-size: 11px; font-style: normal; font-weight: normal">CONTROLMODULE</tspan> | Asset: <tspan style="font-family:Arial;font-size:11px;font-style:normal;font-weight:normal">A5</tspan>
            </tspan>
            <tspan x="15" dy="2.4em">
                Container: <tspan style="font-family: Arial; font-size: 11px; font-style: normal; font-weight: normal">ACE_020FIC</tspan> | System: <tspan style="font-family: Arial; font-size: 11px; font-style: normal; font-weight: normal">ExperionCluster</tspan>
            </tspan>
            <tspan x="15" dy="2.4em">
                <tspan style="font-family: Arial; font-size: 11px; font-style: normal; font-weight: normal"></tspan>: <tspan style="font-family:Arial;font-size:11px;font-style:normal;font-weight:normal"></tspan>
                
            </tspan>
        </text>
        
        

        <use x="0" y="65" transform="rotate(0)" visibility="hidden" href="#ygc1_2">
        </use>
        <use x="0" y="65" transform="rotate(0)" visibility="visible" href="#ygc1_3">
        </use>
        <rect width="20" height="20" fill="transparent" cursor="pointer" onclick="handleConnection(this, event, 'us')" data-json="{&quot;SystemName&quot;:&quot;ExperionCluster&quot;,&quot;systemId&quot;:4,&quot;ItemId&quot;:&quot;4782&quot;,&quot;ItemType&quot;:&quot;0&quot;,&quot;usExpanded&quot;:true,&quot;dsExpanded&quot;:true}" x="2" y="65"></rect>
        <use x="253.37" y="65" transform="rotate(0)" visibility="hidden" href="#ygc1_2">
        </use>
        <use x="253.37" y="65" transform="rotate(0)" visibility="visible" href="#ygc1_3">
        </use>
        <rect width="20" height="20" fill="transparent" cursor="pointer" onclick="handleConnection(this, event, 'ds')" data-json="{&quot;SystemName&quot;:&quot;ExperionCluster&quot;,&quot;systemId&quot;:4,&quot;ItemId&quot;:&quot;4782&quot;,&quot;ItemType&quot;:&quot;0&quot;,&quot;usExpanded&quot;:true,&quot;dsExpanded&quot;:true}" x="253.37" y="65"></rect>
        
        
        <rect fill="#f8eee9" class="hoverable" fill-opacity="1" stroke-width="2" height="30" x="1" y="99" width="267.37" data-attr1="true"></rect>
        
        <use onclick="navigationBtnClickHandle(this, event, 'Anomaly')" x="16.1622" y="99" transform="rotate(0)" href="#ygc1_4">
        </use>
        <text font-family="Arial" font-size="10px" font-style="normal" font-weight="normal" text-anchor="left" onclick="navigationBtnClickHandle(this, event, 'Anomaly')" fill="#1071B5" fill-opacity="1" cursor="pointer" x="38.789280000000005" y="120">Anomaly</text>

        
        <use onclick="navigationBtnClickHandle(this, event, 'Changes')" x="102.36059999999999" y="99" transform="rotate(0)" href="#ygc1_5">
        </use>
        <text font-family="Arial" font-size="10px" font-style="normal" font-weight="normal" text-anchor="left" onclick="navigationBtnClickHandle(this, event, 'Changes')" fill="#1071B5" fill-opacity="1" cursor="pointer" x="127.14264000000001" y="120">Changes</text>

        
        <use onclick="navigationBtnClickHandle(this, event, 'Notes')" style="" x="196.10136" y="99" transform="rotate(0)" href="#ygc1_6">
        </use>
        <text font-family="Arial" font-size="10px" font-style="normal" font-weight="normal" text-anchor="left" onclick="navigationBtnClickHandle(this, event, 'Notes')" fill="#1071B5" fill-opacity="1" cursor="pointer" style="" x="220.8834" y="120">Notes</text>
        
    </g>`;