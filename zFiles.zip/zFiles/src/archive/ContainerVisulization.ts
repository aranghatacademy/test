import { BaseClass, IRenderContext, IVisualCreator, PartitionGrid, SvgVisual, Visual } from 'yfiles'

/**
 * Visualizes the partition grid that has been used in the layout.
 * Each grid cell is visualized as an SVG rectangle.
 */
export default class ContainerVisulization extends BaseClass(IVisualCreator) {
 

  /**
   * Creates a new instance of PartitionGridVisualCreator.
   * @param grid The partition grid to be visualized
   */
  constructor() {
    super()
  }

  /**
   * Creates the visual for the given partition grid inside a container with a title.
   * @param context The context that describes where the visual will be used
   * @returns The visual for the given partition grid
   */
  createVisual(context: IRenderContext): SvgVisual {
    const container = document.createElementNS('http://www.w3.org/2000/svg', 'g')

    // Create a title for the container
    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect')
    rect.setAttribute('x', `-100`)
    rect.setAttribute('y', `-900`)
    rect.setAttribute('width', `900`)
    rect.setAttribute('height', `600`)
    rect.setAttribute('stroke', 'red')
    rect.setAttribute('fill', 'white')


    container.appendChild(rect);
    container.setAttribute("class","outerrectangle");

    return new SvgVisual(container)
  }

  /**
   * Updates the visual for the given partition grid.
   * @param context The context that describes where the visual will be used
   * @param oldVisual The visual instance that had been returned the last time the createVisual
   *   method was called on this instance
   * @returns The visual for the given partition grid
   */
  updateVisual(context: IRenderContext, oldVisual: Visual): SvgVisual {
    return this.createVisual(context)
  }
}
