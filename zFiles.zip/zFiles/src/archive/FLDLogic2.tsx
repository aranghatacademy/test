import { useEffect, useRef, useState } from "react";
import { GraphBuilder, GraphComponent, HierarchicLayout, IGraph, INode, LayoutOrientation, Rect, StringTemplateNodeStyle, TemplateNodeStyle, TemplateNodeStyleRenderer } from "yfiles"

export default function FLDLogic2(){

    const graphDivRef = useRef<HTMLDivElement>(null);
    const graphComponent = useRef<GraphComponent | null>(null);
    const [graph,setGraph] = useState<IGraph | null>(null);

    const nodeTemplateID = "nodeTemplate";
   const nodeTemplate = `
   <g>
        <rect fill='blue' stroke='#2C4E86' stroke-width='2' width='100' height='100'></rect>
        <text x='0' y='0' data-content="{Binding name}" fill="black"></text>
    </g>
  `;

    useEffect(() => {
        if (graphDivRef.current && !graphComponent.current){
            graphComponent.current = new GraphComponent(graphDivRef.current);
            setGraph(graphComponent.current.graph);

           
        }
    }, [graphDivRef.current]);

    useEffect(() => {
        if(graph)
        {
            console.debug("Graph Updated");
          
            graphComponent.current!.fitGraphBounds();
             // Add Some Root Nodes
             addRootNodes();
        }
    }, [graph]);

    function addRootNodes(){
        if(graph)
        {
            console.debug("Adding Root Nodes");
            let data1 =  {name : "John Doe", email : "jhon@test.com"};
            let data2 = {name : "Jane Doe", email : "jane@test.com"};

            let templateNodeStyle = new StringTemplateNodeStyle(nodeTemplate);
           
            const graphBuilder = new GraphBuilder(graph);
                graphBuilder.createNodesSource({
                data: [data1,data2],
                id: () => Math.random().toString(),
                tag: data => data,
                style: () => templateNodeStyle
                });
                graphBuilder.buildGraph();
        }
    }

    function addLabelsToNodes(nodes:INode[]){
        if(graph)
        {
            /*nodes.forEach(node => {
                graph.addLabel(node,"Node Label");
            });*/
        }
    }

    function addRootNodeEdges(nodes:INode[]){
        if(graph)
        {
            graph.createEdge(nodes[0],nodes[1]);
        }
    }

    function applyLayout(){
        if(graph)
        {
            console.debug("Applying Layout");
            var hierarchicLayout = new HierarchicLayout();
            hierarchicLayout.layoutOrientation = LayoutOrientation.LEFT_TO_RIGHT;
            graph.applyLayout(hierarchicLayout);
            graphComponent.current!.fitGraphBounds();
        }
    }

    return (<>
        <div ref={graphDivRef} style={{width : 1000, height : 800}}></div>
        <button onClick={() => applyLayout()}>Add Root Nodes</button>
    </>)
}