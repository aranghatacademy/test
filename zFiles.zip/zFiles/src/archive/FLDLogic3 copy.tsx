import { useEffect, useRef, useState } from "react";
import { 
  FreeNodePortLocationModel, 
  GraphComponent, 
  GraphEditorInputMode, 
  GroupNodeStyle, 
  HierarchicLayout, 
  IGraph, 
  INode, 
  LayoutOrientation, 
  Rect, 
  StringTemplateNodeStyle,
  LayoutExecutor,
  Size,
  TimeSpan,
  GroupNodeLabelModel,
  PartitionGrid,
  Mapper,
  PartitionGridData,
  PartitionCellId,
  HierarchicLayoutData,
  ITable,
  Table,
  TableNodeStyle
} from "yfiles";
import { parentNodes, childNodes } from "./data";
import { template } from './tempate/roottemplate';

export default function FLDLogic3() {
    const graphDivRef = useRef<HTMLDivElement>(null);
    const graphComponent = useRef<GraphComponent | null>(null);
    const [graph, setGraph] = useState<IGraph | null>(null);

    useEffect(() => {
        if (graphDivRef.current && !graphComponent.current) {
            graphComponent.current = new GraphComponent(graphDivRef.current);
            setGraph(graphComponent.current.graph);
        }
    }, [graphDivRef.current]);

    useEffect(() => {
        if (graph) {
            console.debug("Graph Updated");
            
            // Configure the template for parent nodes
            const templateNodeStyle = new StringTemplateNodeStyle(template);
            graph.nodeDefaults.size = new Size(269.37, 130); // Match the size from the template
            
            // Set default group node style
            graph.groupNodeDefaults.style = new GroupNodeStyle({
                tabFill: '#6B7A99',
                contentAreaFill: '#EBF1F9',
                cornerRadius: 8,
                tabPosition: "top",
            });
            
            const groupLabelModel = new GroupNodeLabelModel();
            graph.groupNodeDefaults.labels.layoutParameter = groupLabelModel.createDefaultParameter();
            
            graphComponent.current!.inputMode = new GraphEditorInputMode({
                allowGroupingOperations: true,
            });
            
            // Add Root Nodes
            addRootNodes();
        }
    }, [graph]);

    function addRootNodes() {
        if (graph) {
            console.debug("Adding Root Nodes");
            
            // Create the template style for parent nodes
            const templateNodeStyle = new StringTemplateNodeStyle(template);
            
            // Create the parent nodes with proper spacing based on template dimensions
            const node1 = graph.createNode(new Rect(0, 0, 269.37, 130));
            node1.tag = parentNodes[0];
            graph.setStyle(node1, templateNodeStyle);
            
            const node2 = graph.createNode(new Rect(600, 0, 269.37, 130));
            node2.tag = parentNodes[1];
            graph.setStyle(node2, templateNodeStyle);
            
            // Create an edge between the two parent nodes
            const portAtNode1 = graph.addPort(node1, FreeNodePortLocationModel.NODE_RIGHT_ANCHORED);
            const portAtNode2 = graph.addPort(node2, FreeNodePortLocationModel.NODE_LEFT_ANCHORED);
            graph.createEdge(portAtNode1, portAtNode2);

            // Apply initial layout
            const hierarchicLayout = new HierarchicLayout();
            hierarchicLayout.nodeToNodeDistance = 400; // Increased to accommodate larger nodes
            hierarchicLayout.layoutOrientation = LayoutOrientation.LEFT_TO_RIGHT;
            
            graph.applyLayout(hierarchicLayout);
            graphComponent.current!.fitGraphBounds();
        }
    }

    async function showChildNodes() {
        if (graph && graphComponent.current) {
            console.debug("Adding Child Nodes");
            
            // Get the existing nodes
            const firstNode = graph.nodes.first();
            const lastNode = graph.nodes.last();
            
            // Remove the existing edge between the parent nodes
            graph.edges.toArray().forEach(edge => {
                graph.remove(edge);
            });
            
            // Create group node that will be placed between the two parent nodes
            const groupNode = graph.createGroupNode({
                tag : { title : "Group Node",color: 'red', }
            });

            
            
            // Create edges from the first node to the group and from the group to the last node
            const portFirstNodeOut = graph.addPort(firstNode, FreeNodePortLocationModel.NODE_RIGHT_ANCHORED);
            const portGroupNodeIn = graph.addPort(groupNode, FreeNodePortLocationModel.NODE_LEFT_ANCHORED);
            graph.createEdge(portFirstNodeOut, portGroupNodeIn);
            
            const portGroupNodeOut = graph.addPort(groupNode, FreeNodePortLocationModel.NODE_RIGHT_ANCHORED);
            const portLastNodeIn = graph.addPort(lastNode, FreeNodePortLocationModel.NODE_LEFT_ANCHORED);
            graph.createEdge(portGroupNodeOut, portLastNodeIn);
            
            var partiationGrid = new PartitionGrid(1,3);
            const table = new Table();
            table.createColumn(100,100,0);
            table.createColumn(100,100,1);
            table.createColumn(100,100,2);

            let tableNode = graph.createNode({
                 style : new TableNodeStyle(table)
            });

            var cellMapper = new Mapper<INode,PartitionCellId>();
            // Add child nodes inside the group node
            childNodes.forEach((element, index) => {
                // Position nodes in a grid inside the group
                const x = 20 + (index % 2) * 120;
                const y = 30 + Math.floor(index / 2) * 80;
                
                const childNode = graph.createNode({
                    layout: new Rect(x, y, 100, 50),
                    parent: tableNode
                });
                
                graph.addLabel(childNode, element.LogicalBlockName);
                childNode.tag = element;
                if(element.Type == "Input")
                     cellMapper.set(childNode, partiationGrid.createCellId(0, 0));
                else if(element.Type == "Logic")
                    cellMapper.set(childNode, partiationGrid.createCellId(0, 1));
                else
                    cellMapper.set(childNode, partiationGrid.createCellId(0, 2));
            });
            
            
            const partitionGridData = new PartitionGridData({
                grid: partiationGrid,
                cellIds: cellMapper
              });
            
            graph.groupNodes(groupNode,[tableNode]);
            graph.adjustGroupNodeLayout(groupNode);

            graph.addLabel({
                owner: groupNode,
                text: "Group Node",
                layoutParameter: new GroupNodeLabelModel().createDefaultParameter()
            });
            
            // Create a new hierarchic layout for the updated graph
            const layout = new HierarchicLayout({
                layoutOrientation: LayoutOrientation.LEFT_TO_RIGHT,
                nodeToNodeDistance: 150,
                considerNodeLabels: true
            });

            const layoutData = new HierarchicLayoutData({
                partitionGridData: partitionGridData
              });
            
            // Create a layout executor to animate the layout
            const executor = new LayoutExecutor({
                graphComponent: graphComponent.current,
                layout: layout,
                layoutData: layoutData,
                duration: TimeSpan.fromSeconds(1.5),
                animateViewport: true,
                easedAnimation: true
            });
            
            // Execute the layout with animation
            await executor.start();
            
            // Final adjustment to ensure everything is visible
            graphComponent.current.fitGraphBounds();
        }
    }

    function createPartitionGrid(group:INode){
        const grid = new PartitionGrid(1,3);
        
       
       
    }

    return (
        <>
            <div ref={graphDivRef} style={{width: 1000, height: 800}}></div>
            <button onClick={showChildNodes}>Show Group Between Nodes</button>
        </>
    );
}