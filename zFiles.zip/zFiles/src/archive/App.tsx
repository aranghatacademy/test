import { useEffect, useRef } from 'react'
import './App.css'
import { GraphBuilder, GraphComponent, GraphEditorInputMode, HierarchicLayout, HierarchicLayoutNodeLayoutDescriptor, ICanvasObjectDescriptor, INode, LayoutOrientation, NodeLabelMode, PartitionGrid, PartitionGridData, Point, Size } from 'yfiles'
import SimplePartitionGridVisualCreator from './SimplePartitionGridVisualCreator';
import graphData from './SampleData';

function App() {
  const divRef = useRef<HTMLDivElement>(null);
  const graphComponentRef = useRef<GraphComponent | null>(null);
  const partitionGridRef = useRef<PartitionGrid | null>(null);
  function getColumnIndex(containerTypeName: string): number {
    return (containerTypeName === "InputArea" ? 0 :
      containerTypeName === "LogicArea" ? 1 : 2)
  }
  useEffect(() => {
    // Ensure we only create the GraphComponent once
    if (divRef.current && !graphComponentRef.current) {
      // Create and store the GraphComponent instance
      graphComponentRef.current = new GraphComponent(divRef.current);
      graphComponentRef.current.inputMode = new GraphEditorInputMode();
      const graphComponent = graphComponentRef.current;

      const { graph } = graphComponent;
      const partitionGrid = new PartitionGrid(2,3);
      graph.nodeDefaults.size = new Size(150,100);

    

     partitionGridRef.current = partitionGrid;

     const partitionGridVisualizer = new SimplePartitionGridVisualCreator(partitionGridRef.current);
     graphComponent.backgroundGroup.addChild(partitionGridVisualizer,ICanvasObjectDescriptor.ALWAYS_DIRTY_INSTANCE);
     //graphComponent.fitGraphBounds();

     const builder = new GraphBuilder(graph);
     builder.createNodesSource({
      data: graphData.nodes,
      id : "id",
      labels : ['label'],
      tag : item => ({columnIndex : item.column > 2 ? 2 : item.column, rowIndex : 1})
     });

    builder.createEdgesSource(graphData.edges, 'source', 'target');
    builder.buildGraph();

      

     const layoutAlgorithm = new HierarchicLayout({
      orthogonalRouting: true,
      nodeToNodeDistance: 25,
      integratedEdgeLabeling: true,
      layoutOrientation: LayoutOrientation.LEFT_TO_RIGHT,
      nodeLayoutDescriptor: new HierarchicLayoutNodeLayoutDescriptor({
        layerAlignment: 1,
        nodeLabelMode: NodeLabelMode.CONSIDER_FOR_DRAWING,
      })
       
    });


    partitionGrid.columns.forEach((column) => {
      if(column.index == 0)
      {
        column.minimumWidth = 200;
        column.computedWidth = 200;
        column.computedPosition = 0;
        column.leftInset = 10;
      }
      else if(column.index == 1)
      {
        column.minimumWidth = 500;
        column.computedWidth = 500;
        column.computedPosition = 200;
        column.leftInset = 30;
      }
      else if(column.index == 2)
      {
        column.minimumWidth = 200;
        column.computedWidth = 200;
        column.computedPosition = 700;
      }
    });

    const partitionGridData = new PartitionGridData({
      grid: partitionGrid,
      cellIds: (node: INode) => {
        return partitionGrid.createCellId(node.tag.rowIndex, node.tag.columnIndex);
      }
    });

    // applies the layout algorithm to the graph
    graphComponent.morphLayout(layoutAlgorithm, '1s', partitionGridData);
    //graphComponent.();
    }
  }, []);



  return (
    <>
      <div 
        ref={divRef}
        style={{ width: '900px', height: '600px', border: '1px solid #ccc' }}
      />
    </>
  );
}

export default App;
