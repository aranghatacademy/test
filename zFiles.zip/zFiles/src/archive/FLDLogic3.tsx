import { useEffect, useRef, useState } from "react";
import { FreeNodePortLocationModel, GraphBuilder, GraphComponent, GraphEditorInputMode, GroupNodeStyle, HierarchicLayout, IGraph, INode, LayoutOrientation, Rect, StringTemplateNodeStyle } from "yfiles";
import { parentNodes,childNodes } from "./data";
import { template } from './tempate/roottemplate';

export default function FLDLogic3() {
    const graphDivRef = useRef<HTMLDivElement>(null);
    const graphComponent = useRef<GraphComponent | null>(null);
    const [graph, setGraph] = useState<IGraph | null>(null);

    useEffect(() => {
        if (graphDivRef.current && !graphComponent.current) {
            graphComponent.current = new GraphComponent(graphDivRef.current);
            setGraph(graphComponent.current.graph);
        }
    }, [graphDivRef.current]);

    useEffect(() => {
        if (graph) {
            console.debug("Graph Updated");
            graphComponent.current!.fitGraphBounds();
            graphComponent.current!.inputMode = new GraphEditorInputMode()
            // Add Some Root Nodes
            addRootNodes();
        }
    }, [graph]);

    function addRootNodes() {
        if (graph) {
            console.debug("Adding Root Nodes");
            let templateNodeStyle = new StringTemplateNodeStyle(template);
            let x = 0;
            for (let i = 0; i < parentNodes.length; i++) {
                let data = parentNodes[i];
                let node = graph.createNode();
                graph.addLabel(node, data.LogicalBlockName);
                node.tag = data;
                graph.setStyle(node, templateNodeStyle);
            }

            const node1 = graph.nodes.first()
            const node3 = graph.nodes.last()
            const portAtNode1 = graph.addPort(node1)
            const portAtNode3 = graph.addPort(node3, FreeNodePortLocationModel.NODE_CENTER_ANCHORED)
            const edgeAtPorts = graph.createEdge(portAtNode1, portAtNode3)

            var hierarchicLayout = new HierarchicLayout();
            hierarchicLayout.nodeToNodeDistance = 300;
            hierarchicLayout.layoutOrientation = LayoutOrientation.LEFT_TO_RIGHT;
            graph.applyLayout(hierarchicLayout);
            
        }
    }

    function showChildNodes() {
        if (graph) {
            console.debug("Adding Child Nodes");
            let firstNode = graph.nodes.first();
            let lastNode = graph.nodes.last();
            let node = graph.createGroupNode();
             graph.addLabel(node,"Parent Node");

             graph.createEdge(firstNode,node);
             graph.createEdge(node,lastNode);

            let groupNodes:INode[] = [];
            childNodes.forEach(element => {
                let n = graph.createNode(node);
                graph.addLabel(n,element.LogicalBlockName);
                groupNodes.push(n);
            });

            graph.groupNodeDefaults.style = new GroupNodeStyle();
            graph.groupNodes(groupNodes);
            graph.adjustGroupNodeLayout(node);
            graph.applyLayout(new HierarchicLayout({layoutOrientation : LayoutOrientation.LEFT_TO_RIGHT}));
            //graphComponent.current!.fitGraphBounds();
        }  
    }

    return (<>
     <div ref={graphDivRef} style={{width : 1000, height : 800}}></div>
     <button onClick={showChildNodes}>Add Root Nodes</button>
    </>)
}