import { INode, IRenderContext, NodeStyleBase, SvgVisual, Visual } from "yfiles";

export default class CustomNodeStyle extends NodeStyleBase {
    protected createVisual(context: IRenderContext, node: INode): Visual | null {
        const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect')
        const { x, y, width, height } = node.layout
        rect.setAttribute('x', String(x))
        rect.setAttribute('y', String(y))
        rect.setAttribute('width', String(width))
        rect.setAttribute('height', String(height))
        rect.setAttribute('fill', 'red')
        rect.setAttribute('stroke', '#042d37')
        return new SvgVisual(rect)
      }
}