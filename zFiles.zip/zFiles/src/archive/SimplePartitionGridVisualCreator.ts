import { BaseClass, IRenderContext, IVisualCreator, PartitionGrid, SvgVisual, Visual } from 'yfiles'

/**
 * Visualizes the partition grid that has been used in the layout.
 * Each grid cell is visualized as an SVG rectangle.
 */
export default class SimplePartitionGridVisualCreator extends BaseClass(IVisualCreator) {
  private grid: PartitionGrid

  /**
   * Creates a new instance of PartitionGridVisualCreator.
   * @param grid The partition grid to be visualized
   */
  constructor(grid: PartitionGrid) {
    super()
    this.grid = grid
  }

  /**
   * Creates the visual for the given partition grid inside a container with a title.
   * @param context The context that describes where the visual will be used
   * @returns The visual for the given partition grid
   */
  createVisual(context: IRenderContext): SvgVisual {
    const container = document.createElementNS('http://www.w3.org/2000/svg', 'g')

    // Create a title for the container
    const title = document.createElementNS('http://www.w3.org/2000/svg', 'text')
    title.textContent = 'FLD Logic 2'
    title.setAttribute('x', '50%')
    title.setAttribute('y', '-20') // Positioning above the grid
    title.setAttribute('text-anchor', 'middle')
    title.setAttribute('font-size', '16')
    title.setAttribute('font-weight', 'bold')
    title.setAttribute('fill', 'black')

    container.appendChild(title);
    container.setAttribute("fill","blue");

    for (const row of this.grid.rows) {
      for (const column of this.grid.columns) {
        const x = column.computedPosition
        const y = row.computedPosition
        const h = row.computedHeight
        const w = column.computedWidth

        // Create grid cell as a rectangle
        const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect')
        rect.setAttribute('x', `${x}`)
        rect.setAttribute('y', `${y}`)
        rect.setAttribute('width', `${w}`)
        rect.setAttribute('height', `${h}`)
        rect.setAttribute('stroke', 'red')
        rect.setAttribute('fill', 'white')

        container.appendChild(rect)
      }
    }

    return new SvgVisual(container)
  }

  /**
   * Updates the visual for the given partition grid.
   * @param context The context that describes where the visual will be used
   * @param oldVisual The visual instance that had been returned the last time the createVisual
   *   method was called on this instance
   * @returns The visual for the given partition grid
   */
  updateVisual(context: IRenderContext, oldVisual: Visual): SvgVisual {
    return this.createVisual(context)
  }
}
