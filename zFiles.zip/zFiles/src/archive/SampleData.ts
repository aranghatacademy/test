export default {
  nodes: [
    {
      id: 1,
      column: 0,
      row: 1,
      label: 'ESD216_FLD1315.ESD216_FLD1315 ( 1310 , 1315 ) 1'
    },
    {
      id: 2,
      column: 1,
      row: 1,
      label: 'ESD216_FLD1315.DelayOnVar ( 1 s ) '
    },
    {
      id: 3,
      column: 2,
      row: 1,
      label: 'ESD216_FLD1315.ST_X7051_D'
    },
    {
      id: 4,
      column: 1,
      row: 1,
      label: 'ESD216_FLD1315.INV'
    },
    {
      id: 5,
      column: 1,
      row: 1,
      label: 'ESD216_FLD1315.NOR'
    },
    {
      id: 6,
      column: 2,
      row: 1,
      label: 'ESD216_FLD1315.ESD216_FLD1315 ( 1315 , 1070 ) 2'
    },
    {
      id: 7,
      column: 0,
      row: 1,
      label: 'ESD216_FLD1315.ST_X7051_GOSZ'
    },
    {
      id: 8,
      column: 0,
      row: 1,
      label: 'ESD216_FLD1315.ST_X7051_GOSA'
    },
    {
      id: 9,
      column: 2,
      row: 1,
      label: 'ESD216_FLD1315.NOR'
    },
    {
      id: 10,
      column: 1,
      row: 1,
      label: 'ESD216_FLD1315.AND'
    },
    {
      id: 11,
      column: 2,
      row: 1,
      label: 'ESD216_FLD1315.ST_X7051_GOSA'
    }
  ],

  edges: [
    {
      source: 1,
      target: 0
    },
    {
      source: 1,
      target: 2
    },
    {
      source: 7,
      target: 4
    },
    {
      source: 7,
      target: 5
    },
    {
      source: 8,
      target: 10
    },
    {
      source: 0,
      target: 3
    },
    {
      source: 2,
      target: 6
    },
    {
      source: 4,
      target: 9
    },
    {
      source: 5,
      target: 11
    },
    {
      source: 10,
      target: 11
    }
  ],

  groups: [
    {
      id: 'group1'
    },
    {
      id: 'group2'
    }
  ]
}
