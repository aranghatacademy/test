import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import { License } from 'yfiles'
import licenseValue from './license.json'
import FLDLogic4 from './FLDLogic4'

License.value = licenseValue;

createRoot(document.getElementById('root')!).render(
  <StrictMode>
     <FLDLogic4 />
  </StrictMode>,
)
