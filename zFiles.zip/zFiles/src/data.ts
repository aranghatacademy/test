export const parentNodes = [{
    Id : 1,
    LogicalBlockName : "AA0001",
    Description : "This is a test description",
    System : "System 1",
},
{
    Id :2,
    LogicalBlockName : "AA0002",
    Description : "This is a test description",
    System : "System 2",
}
]

export const childNodes = [{
    Id : 1,
    LogicalBlockName : "Inout 001",
    Description : "This is a test description",
    System : "System 1",
    Type: "Input"
},
{
    Id :2,
    LogicalBlockName : "Logic 001",
    Description : "This is a test description",
    System : "System 2",
    Type: "Logic"
},
{
    Id :3,
    LogicalBlockName : "Output 001",
    Description : "This is a test description",
    System : "System 2",
    Type: "Output"
},
{
    Id :4,
    LogicalBlockName : "Input 002",
    Description : "This is another test description",
    System : "System 3",
    Type: "Input"
},
{
    Id :5,
    LogicalBlockName : "Logic 002",
    Description : "This is another test description",
    System : "System 3",
    Type: "Logic"
},
{
    Id :6,
    LogicalBlockName : "Output 002",
    Description : "This is another test description",
    System : "System 3",
    Type: "Output"
}
]