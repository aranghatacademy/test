import { TemplateNodeStyleRenderer } from "yfiles";

export class CustomTemplateRenderer extends TemplateNodeStyleRenderer
{

}